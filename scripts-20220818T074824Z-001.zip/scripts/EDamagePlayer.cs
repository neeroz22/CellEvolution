using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EDamagePlayer : MonoBehaviour
{
    public float damage;
    public PlayerHealth playerHealth;

    private void OnTriggerStay2D (Collider2D other)
    {
        if(other.CompareTag("Enemy"))
        {
            playerHealth.TakeDamage(damage);

        }
    }
}
