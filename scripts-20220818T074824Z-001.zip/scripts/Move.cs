using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
     public float Speed;
    void Start()
    {
        transform.position = new Vector3(0, 0, 0);
    }

    void Update()
    {
        /*if (transform.position.y >= 384)
        {
            transform.position = new Vector3  (transform.position.x, 384, 0);
        } 
        else if (transform.position.y >= -384)
        {
            transform.position = new Vector3  (transform.position.x, -384, 0);
        }
        else if (transform.position.x >= 640)
        {
            transform.position = new Vector3  (640, transform.position.y, 0);
        }
        else if (transform.position.x >= -640)
        {
            transform.position = new Vector3  (-640, transform.position.y, 0);
        }*/
        
        if (Input.GetMouseButton(0)){
            Vector3 Target = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Target.z = transform.position.z;

            transform.position = Vector3.MoveTowards(transform.position, Target, Speed * Time.deltaTime);
        }
        //FaceMouse();
    }
    void FaceMouse()
    {
        Vector3 mousePosition = Input.mousePosition;
        mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);

        Vector2 direction = new Vector2 
        (
            mousePosition.x = transform.position.x,
            mousePosition.y = transform.position.y
        );

        transform.up = direction;
    }
    
}
