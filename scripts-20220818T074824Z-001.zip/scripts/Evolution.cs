using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Evolution : MonoBehaviour
{
    public LevelSystem levelsystem;
    [SerializeField] GameObject PEvolution;
    // Update is called once per frame
    void Update()
    {
        if (levelsystem.level == 10)
        {
            PEvolution.SetActive(true);
        }
    }
}
