using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    [SerializeField] GameObject menu;

    
    public void Pause()
    {
        menu.SetActive(true);
        Time.timeScale = 0f;
    }
    
    public void Resume()
    {
        menu.SetActive(false);
        Time.timeScale = 1f;
    }

    public void MainMenu(int SceneID)
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneID);
    }
}
